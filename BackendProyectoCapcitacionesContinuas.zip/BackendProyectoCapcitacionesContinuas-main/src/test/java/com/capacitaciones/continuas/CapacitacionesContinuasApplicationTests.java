package com.capacitaciones.continuas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapacitacionesContinuasApplicationTests {

	@Test
	void contextLoads() {
	}

}
