package com.capacitaciones.continuas.services;

import com.capacitaciones.continuas.Modelos.Primary.ModalidadCurso;

public interface ModalidadCursoService extends  GenericService<ModalidadCurso, Integer>{
}
