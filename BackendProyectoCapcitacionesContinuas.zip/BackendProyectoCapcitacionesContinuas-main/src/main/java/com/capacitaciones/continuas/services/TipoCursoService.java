package com.capacitaciones.continuas.services;

import com.capacitaciones.continuas.Modelos.Primary.TipoCurso;

public interface TipoCursoService extends  GenericService<TipoCurso, Integer>{
}
