package com.capacitaciones.continuas.emailValidator.Dto;

import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class ZeroBounceResponse {
    private String address;
    private String status;
    // Other fields


    // Getters and setters
}