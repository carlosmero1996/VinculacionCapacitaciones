package com.capacitaciones.continuas.services;

import com.capacitaciones.continuas.Modelos.Primary.Canton;
import com.capacitaciones.continuas.Modelos.Primary.Provincia;

import java.util.List;

public interface ProvinciaService extends  GenericService<Provincia, Integer>{

}
