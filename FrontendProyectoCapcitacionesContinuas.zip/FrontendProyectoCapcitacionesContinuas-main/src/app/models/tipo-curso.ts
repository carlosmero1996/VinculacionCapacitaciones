export class TipoCurso {
    idTipoCurso?: number;
    estadoTipoCurso?: boolean;
    nombreTipoCurso?: string;
}
