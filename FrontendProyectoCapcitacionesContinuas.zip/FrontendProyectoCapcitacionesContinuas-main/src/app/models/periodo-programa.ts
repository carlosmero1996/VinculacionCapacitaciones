export class PeriodoPrograma {
    idPeriodoPrograma?: number;
    estadoPeriodoPrograma?: boolean;
    fechaInicioPeriodoPrograma?: Date;
    fechaFinPeriodoPrograma?: Date;
    nombrePeriodoPrograma?: string;
}