import { Silabo } from "./silabo";

export class DisenioCurriculares {
    idDisenioCurricular?: number;
    temasTransversales?: string;
    estrategiasAprendizaje?: String;
    estadoDisenioCurricular?: Boolean;
    silabo?: Silabo;
}
