import { Capacitador } from "./capacitador";

export class HojaVidaCapacitador {
    idHojaVida?: number;
    experiencialLaboral?: string;
    sobreMi?: string;
    experienciaEscolar?: string;
    destrezas?: string;
    idiomas?: string;
    estadoAprobacion?: string;
    documento?: any;
    capacitador?: Capacitador;
}
