export class ModalidadCurso {
    idModalidadCurso?: number;
    estadoModalidadCurso?: boolean;
    nombreModalidadCurso?: string;
}
