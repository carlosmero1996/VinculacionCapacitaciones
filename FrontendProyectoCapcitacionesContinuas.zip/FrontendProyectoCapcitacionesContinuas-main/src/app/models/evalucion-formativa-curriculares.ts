import { DisenioCurriculares } from "./disenio-curriculares";

export class EvalucionFormativaCurriculares {
    idEvalucionFormativaCurricular?: number;
    tecnicaFormativa?: string;
    instrumnetoFormativa?: String;
    estadoEvaluacionFormativa?: Boolean;
    disenioCurricular?: DisenioCurriculares;
}

