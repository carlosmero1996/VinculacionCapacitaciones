export class NivelCurso {
    idNivelCurso?: number;
    estadoNivelCurso?: boolean;
    nombreNivelCurso?: string;
}
