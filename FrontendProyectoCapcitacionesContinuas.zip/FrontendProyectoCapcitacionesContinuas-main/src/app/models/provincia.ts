export class Provincia {
  idProvincia?: number;
  provincia?: string;
}
