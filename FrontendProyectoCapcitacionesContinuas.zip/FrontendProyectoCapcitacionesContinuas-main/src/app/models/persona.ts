export class Persona {
    idPersona?: number;
    identificacion?: String;
    nombre1?: String;
    nombre2?: String;
    apellido1?: String;
    apellido2?: String;
    fechaNacimiento?: Date;
    genero?: String;
    direccion?: String;
    correo?: String;
    telefono?: string;
    celular?: string;
    etnia?: string;
    nivelInstruccion?: string;
}