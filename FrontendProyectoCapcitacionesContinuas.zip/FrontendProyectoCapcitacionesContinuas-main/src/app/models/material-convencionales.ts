import { Silabo } from "./silabo";

export class MaterialConvencionales {

    idMaterialConvencional?: number;
    descripcionMaterialConvencional?: string;
    estadoMaterialConvencional?: Boolean;
    silabo?: Silabo;
}

