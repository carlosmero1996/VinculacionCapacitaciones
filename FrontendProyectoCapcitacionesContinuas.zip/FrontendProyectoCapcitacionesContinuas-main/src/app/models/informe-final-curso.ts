import { Curso } from "./curso";

export class InformeFinalCurso {
    idInformeFinalCurso?: number;
    observacionesInformeFinalCurso?: string;
    lugarInformeFinalCurso?: string;
    nombreCantonInformeFinalCurso?: string;
    curso?: Curso;
}
