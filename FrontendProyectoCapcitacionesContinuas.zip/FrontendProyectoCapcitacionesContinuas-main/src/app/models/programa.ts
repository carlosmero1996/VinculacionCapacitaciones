import { PeriodoPrograma } from "./periodo-programa";
export class Programas {
    idPrograma?: number;
    nombrePrograma?: string;
    descripcionPrograma?: string;
    estadoProgramaActivo?: boolean;
    periodoPrograma?: PeriodoPrograma
}