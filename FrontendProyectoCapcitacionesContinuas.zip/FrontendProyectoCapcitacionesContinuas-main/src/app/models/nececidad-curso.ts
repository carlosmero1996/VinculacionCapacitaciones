import { Curso } from "./curso";

export class NececidadCurso {
    idNecesidadCurso?: number;
    espacioImpartirNecesidadCurso?:string;
    resumenCurso?: string;
    poblacionDirijida?: string;
    curso?: Curso;
}
