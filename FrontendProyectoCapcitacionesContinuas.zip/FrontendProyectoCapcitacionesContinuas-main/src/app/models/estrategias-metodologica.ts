import { Silabo } from "./silabo";

export class EstrategiasMetodologica {
    idEstrategiaMetodologica?: number;
    nombreEstrategiaMetodologica?: string;
    finalidadEstrategiaMetodologica?: string;
    estadoEstrategiaMetodologicaActivo?: Boolean;
    silabo?: Silabo;
}
