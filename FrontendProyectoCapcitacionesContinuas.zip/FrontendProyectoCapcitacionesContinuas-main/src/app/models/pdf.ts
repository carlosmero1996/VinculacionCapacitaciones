import { Persona } from "./persona";
import { Rol } from "./rol";

export class PruebaPdf {
    idpruebaPdfs?: number;
    nombre?: string;
    pdf?: string;
    exel?: string

}
