import { Provincia } from './provincia';

export class Canton {
  idCanton?: number;
  canton?: string;
  provincia?: Provincia;
}
