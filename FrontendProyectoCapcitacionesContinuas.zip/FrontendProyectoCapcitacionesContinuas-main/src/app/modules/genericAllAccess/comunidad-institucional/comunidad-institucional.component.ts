import { Component } from '@angular/core';

@Component({
  selector: 'app-comunidad-institucional',
  templateUrl: './comunidad-institucional.component.html',
  styleUrls: ['./comunidad-institucional.component.css']
})
export class ComunidadInstitucionalComponent {

}
