export const environment = {
  // apiuri: 'http://capacitaciones-continuas-ista.us-east-1.elasticbeanstalk.com/api',
  // apiUriSecurity: 'http://capacitaciones-continuas-ista.us-east-1.elasticbeanstalk.com/auth',


  // apiuri: 'http://localhost:8080/api',
  // apiUriSecurity: 'http://localhost:8080/auth',

  apiuri: 'http://161.35.10.103:8080/api',
  apiUriSecurity: 'http://161.35.10.103:8080/auth',

  // apiuri: 'http://178.128.153.94:8080/api',
  // apiUriSecurity: 'http://178.128.153.94:8080/auth',
 
};
